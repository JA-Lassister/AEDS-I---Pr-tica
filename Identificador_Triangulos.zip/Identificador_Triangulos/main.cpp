/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo - 2024.1.08.027
 *
 * Created on 12 de março de 2024, 17:12
 */

#include <iostream>

using namespace std;

/*Código Identificador de Triângulos
 
 O código tem como objetivo identificar de três valores formam um triângulo e como este triângulo pode ser definido.
 Através de uma série de comandos de condição.*/

int main(int argc, char** argv) {
    
    float lado1, lado2, lado3;      
    
    cout << "Digite a medida do 1º lado: ";
    cin >> lado1;
    while ( lado1 < 0 || lado1 == 0 ){
        cout << "Valor inválido. Digite novamente: ";
        cin >> lado1;
    }    
    cout << "Digite a medida do 2° lado: ";
    cin >> lado2;
    while ( lado2 < 0 || lado2 == 0 ){
        cout << "Valor inválido. Digite novamente: ";
        cin >> lado2;
    }
    cout << "Digite a medida do 3º lado: ";
    cin >> lado3;
    while ( lado3 < 0 || lado3 == 0 ){
        cout << "Valor inválido. Digite novamente: ";
        cin >> lado3;
    }
    
    if ( lado1 + lado2 < lado3 || lado1 + lado3 < lado2 || lado2 + lado3 < lado1){
        cout << "\nNão é um triângulo.";
    } else
        if ( lado1 == lado2 && lado1 == lado3 ){
            cout << "\nÉ um triângulo equilátero.";
        } else
            if ( lado1 == lado2 && lado1 != lado3 || lado1 == lado3 && lado1 != lado2 || lado2 == lado3 && lado2 != lado1){
                cout << "\nÉ um triângulo isóceles.";
            } else
                if ( lado1 * lado1 + lado2 * lado2 == lado3 * lado3 || lado1 * lado1 + lado3 * lado3 == lado2 * lado2 || lado2 * lado2 + lado3 * lado3 == lado1 * lado1){
                        cout << "\nÉ um triângulo retângulo.";
                    } else
                        cout << "\nÉ um triângulo escaleno";
                
            
         
    
    

    return 0;
}

