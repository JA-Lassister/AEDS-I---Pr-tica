/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 29 de abril de 2024, 16:07
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

/*Código para armazenar informações em registros.
 * 
 * O código lê informações através de um arquivo texto, transporta para um vetor,
 * realiza operações, e então substitui o arquivo texto com as novas informações.
 * 
 */

const int TAM = 100;

typedef struct{
    bool valido;
    string nome;
    string celular;
    string cidade;
    string email;
}Pessoa;

int main(int argc, char** argv) {
    
    //Declaração das variáveis
    Pessoa agenda[TAM];
    int i, j, qtd = 0, qtdv, opcao, e;
    string nome;
    ifstream arquivo("agenda.txt");
    
    if (!arquivo.is_open()){
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
    }
    
    //Transposição do arquivo para o vetor
    i = 0;
    arquivo >> nome;
    while(nome != "Fim"){
        agenda[i].nome = nome;
        arquivo >> agenda[i].celular
                >> agenda[i].cidade
                >> agenda[i].email;
        agenda[i].valido = true;
        i++;
        qtd++;
        arquivo >> nome;
    }
    
    arquivo.close();
    
    qtd--;
    qtdv = qtd;
    
    //Opções de manipulação
    do{
        cout << "Digite o número referente ao que deseja realizar." << endl;
        cout << " 1 - Buscar um contato." << endl;
        cout << " 2 - Adicionar um contato." << endl;
        cout << " 3 - Remover um contato." << endl;
        cout << " 0 - Sair." << endl;
        cin >> opcao;
            
        switch(opcao){
            case 0:
                break;
            //Buscar um contato
            case 1:
                cout << "\nDigite o nome do contato que deseja buscar: ";
                cin >> nome;
                cout << endl;
                
                e = 0;
                
                for (i = 0; i < qtd; i++){
                    if (nome == agenda[i].nome && agenda[i].valido == true){
                        e = 1;
                        cout << agenda[i].nome
                            << " " << agenda[i].celular
                            << " " << agenda[i].cidade
                            << " " << agenda[i].email;
                        cout << endl << endl;
                    }
                }
                if(e == 0){
                    cout << "O contato não está na agenda." << endl;
                    cout << endl;
                }
                break;
            //Adicionar um contato
            case 2:
                if(qtdv == TAM){
                    cout << " A agenda está cheia. Remova um contato antes de adicionar outro.";
                } else {
                    qtdv++;
                    if(qtdv > qtd){
                        qtd = qtdv;
                    }
                    j = qtd;
                    for(i = 0; i <= qtd; i++){
                        if(agenda[i].valido == false){
                            agenda[i].valido = true;
                            j = i;
                            i  = qtd + 1;
                        }
                    }
                    cout << "\n Digite as informações do contato." << endl;
                    cout << " Nome: ";
                    cin >> agenda[j].nome;
                    cout << " Celular: ";
                    cin >> agenda[j].celular;
                    cout << " Cidade: ";
                    cin >> agenda[j].cidade;
                    cout << " E-mail: ";
                    cin >> agenda[j].email;
                    cout << endl;
                }
                break;
            //Remover um contato
            case 3:
                cout << "\n Digite o nome do contato que deseja remover: ";
                cin >> nome;
                cout << endl;
                
                e = 0;
                
                for (i = 0; i <= qtd && e == 0; i++){
                    if (nome == agenda[i].nome && agenda[i].valido == true){
                        e = 1;
                        agenda[i].valido = false;
                        qtdv--;
                    }
                }                
                if(e == 0){
                    cout << " O contato não está na agenda." << endl;
                    cout << endl;
                }
                
                break;
        }
    } while(opcao != 0);
    
    //Substituir as informações do arquivo pelo vetor
    ofstream arquivo1("agenda.txt");
    
    if (!arquivo1.is_open()){
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
    }
    
    for(i = 0; i <= qtd; i++){
        if(agenda[i].valido == true){
            arquivo1 << agenda[i].nome << " "
                    << agenda[i].celular << " "
                    << agenda[i].cidade << " "
                    << agenda[i].email << " "
                    << endl;
        }
    }
    arquivo1 << "Fim";
    
    arquivo1.close();

    return 0;
}


