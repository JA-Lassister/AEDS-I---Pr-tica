/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 23 de abril de 2024, 15:55
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*Código de operações em conjuntos numéricos
 * 
 */
int main(int argc, char** argv) {

    //Declaração das variáveis
    int conjunto1[10] = {5, 4, 2, 5, 3, 2, 4, 8, 2, 9};
    int conjunto2[10] = {7, 1, 12, 10, 9, 2, 8, 1, 2, 7};
    int uniao[20];
    int interseccao[10];
    
    int i, j, k, l, tam1 = 10, tam2 = 10, tamu = 0, tami = 0;
    
    cout << " Operações em conjuntos de valores." << endl << endl;
    
    //Remoção dos valores repetidos conjunto 1
    for (i = 0; i < tam1; i++){
        for (j = i + 1; j < tam1; j++){
            if (conjunto1[i] == conjunto1[j]){
                for (k = j + 1; k != tam1; k++){                                
                    conjunto1[k - 1] = conjunto1[k];
                }
                tam1--;
                j--;
            }
        }    
    }
    
    cout << " conjunto1 = { ";
    for (i = 0; i < tam1; i++){
        cout << conjunto1[i] << " ";
    }
    cout << "}" << endl;
    
    //Remoção dos valores repetidos conjunto 2
    for (i = 0; i < tam2; i++){
        for (j = i + 1; j < tam2; j++){
            if (conjunto2[i] == conjunto2[j]){
                for (k = j + 1; k != tam2; k++){                                
                    conjunto2[k - 1] = conjunto2[k];
                }
                tam2--;
                j--;
            }
        }    
    }
    
    cout << " conjunto2 = { ";
    for (i = 0; i < tam2; i++){
        cout << conjunto2[i] << " ";
    }
    cout << "}" << endl;
    
    //União dos conjuntos
    j = tam1;
    
    for(i = 0; i < tam1; i++){
        uniao[i] = conjunto1[i];
    }
    for(i = 0; i < tam2; i++){
        uniao[j] = conjunto2[i];
        j++;
    }
    
    tamu = tam1 + tam2;
    
    for (i = 0; i < tamu; i++){
        for (j = i + 1; j < tamu; j++){
            if (uniao[i] == uniao[j]){
                for (k = j + 1; k != tamu; k++){                                
                    uniao[k - 1] = uniao[k];
                }
                tamu--;
                j--;
            }
        }    
    }
    
    cout << "\n A união dos dois conjuntos é : { ";
    for (i = 0; i < tamu; i++){
        cout << uniao[i] << " " ;
    }
    cout << "}" << endl;
    
    //Intersecção dos conjuntos    
    l = 0;
    
    for (i = 0; i < tam1; i++){
        for (j = 0; j < tam2; j++){
            if ( conjunto1[i] == conjunto2[j]){
                interseccao[l] = conjunto1[i];
                l++;
                tami++;
            } 
        }        
    }
    
    if (tami != 0){
        cout << "\n A intersecção dos dois conjuntos é: { ";
        for (i = 0; i < tami; i++){
            cout << interseccao[i] << " " ;
        }
        cout << "}" << endl;
    } else {
        cout << "\n A intersecção dos dois conjuntos é vazia.";
    }
    

    
    return 0;
}


