/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 1 de abril de 2024, 17:37
 */

#include <iostream>
#include <fstream>
#include <valarray>
#include <math.h>

#define pi 3.14159265359

using namespace std;

/*Projeto Cena Gráfica
 * 
 * O programa, a partir de um arquivo-texto que contenha objetos geométricos (2D ou 3D) e seus parâmetros distribuídos em linhas,
 * calcula e escreve na tela o volume e área (quando possível) de cada objeto, como também, o volume e área total da cena.
 * 
 */
int main(int argc, char** argv) {
    
    float lado1, lado2, altura, raio, volume, area, areat, volumet;
    string objeto;
    ifstream arquivo ("cenagrafica.txt");
    
    if (!arquivo.is_open()){
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
    }
    
    areat = 0;
    volumet = 0;
    
    cout << "Cena Gráfica" << endl;
    
    arquivo >> objeto;
    
    while (objeto != "Fim"){
        if (objeto == "Cubo"){
            arquivo >> lado1;
            volume = lado1*lado1*lado1;
            area = 6 * lado1 * lado1;

            cout << "\nVolume do Cubo -> " << volume << endl;
            cout << "Área do Cubo -> "<< area << endl;
        }
        
        else if (objeto == "Quadrado"){
            arquivo >> lado1;
            area = lado1 * lado1;

            cout << "\nÁrea do Quadrado -> "<< area << endl;
             }
        
        else if (objeto == "Paralelepípedo"){
            arquivo >> lado1 >> lado2 >> altura;
            volume = lado1*lado2*altura;
            area = 2 * (lado1*lado2 + lado2*altura + lado1*altura);

            cout << "\nVolume do Paralelepípedo -> " << volume << endl;
            cout << "Área do Paralelepípedo -> "<< area << endl;
             }
        
        else if (objeto == "Retângulo"){
            arquivo >> lado1 >> lado2;
            area = lado1 * lado2;

            cout << "\nÁrea do Retângulo -> "<< area << endl;
             }
        
        else if (objeto == "Pirâmide"){
            arquivo >> lado1 >> altura;
            volume = (lado1*lado1 * altura) / 3;
            area = lado1*lado1 + 2*lado1*sqrt(lado1*lado1 + altura*altura);

            cout << "\nVolume da Pirâmide Quadrangular -> " << volume << endl;
            cout << "Área da Pirâmide Quadrangular -> "<< area << endl;
             }
        
        else if (objeto == "Triângulo"){
            arquivo >> lado1 >> altura;
            area = lado1 * altura / 2;

            cout << "\nÁrea do Triângulo -> "<< area << endl;
             }
        
        else if (objeto == "Cilindro"){
            arquivo >> raio >> altura;
            volume = pi * raio*raio * altura;
            area = 2 * pi*raio * (raio + altura);

            cout << "\nVolume do Cilindro -> " << volume << endl;
            cout << "Área do Cilindro -> "<< area << endl;
             }
        
        else if (objeto == "Esfera"){
            arquivo >> raio;
            volume = 4/3 * (pi * raio*raio*raio);
            area = 4 * pi * raio*raio;

            cout << "\nVolume da Esfera -> " << volume << endl;
            cout << "Área da Esfera -> "<< area << endl;
             }
        
        else if (objeto == "Círculo"){
            arquivo >> raio;
            area = pi * raio*raio;

            cout << "\nÁrea do Círculo -> "<< area << endl;
             }
        
        else if (objeto == "Cone"){
            arquivo >> raio >> altura;
            volume = (pi * raio*raio * altura) / 3;
            area = pi*raio*sqrt(raio*raio + altura*altura) + pi*raio*raio;

            cout << "\nVolume do Cone -> " << volume << endl;
            cout << "Área do Cone -> "<< area << endl;
             }
        

        areat = areat + area;
        volumet = volumet + volume;

        arquivo >> objeto;
    }    
    
    cout << "\nO volume total da cena é: " << volumet << "\tA área total da cena é: " << areat << endl;
    
    arquivo.close();    
    
    return 0;
}

