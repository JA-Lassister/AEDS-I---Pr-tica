/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 9 de abril de 2024, 16:22
 */

#include <time.h>
#include <iostream>

using namespace std;

int main() {
    
    const int TAM = 1000;
    int i, numero[TAM], opcao, busca, e, posicoes[TAM], conta, liminf, limsup;
    
    opcao = 0;
    
    srand (time(NULL));
    
    for (i = 0; i < TAM; i++){
        numero[i] = 100 + rand() % 101;
    }
    
    do {
        cout << "\nDigite o número referente ao tipo de busca que deseja realizar." << endl << endl;
        cout << " 1 - Verificar se um valor está no vetor e sua primeira posição." << endl;
        cout << " 2 - Verificar se um está no vetor e em quais posições." << endl;
        cout << " 3 - Verificar quantas vezes os valores de um determinado intervalo aparecem no vetor." << endl;
        cout << "\n\t\t\t\t\t\t0 - Encerrar programa." << endl;
        cin >> opcao;
        switch (opcao){
            case 0:
                cout << "\nPrograma finalizado." << endl;
                break;
            case 1:
                cout << "\nDigite o valor que deseja buscar." << endl;
                cin >> busca; 
                
                e = 0;
                
                for (i = 0; e == 0 && i < TAM; i++){
                    if (numero[i] == busca){
                        e = 1;
                    }
                }
                if (e == 1){
                    cout << "\nO valor " << busca << " está no vetor, e aparece pela primeira vez na posição " << i << "." << endl;
                } else {
                    cout << "\nO valor " << busca << " não está no vetor." << endl;
                }
                break;
            case 2:
                cout << "\nDigite o valor que deseja buscar." << endl;
                cin >> busca;
                
                e = 0;
                conta = 0;
                
                for (i = 0; i < TAM; i++){
                    if (numero[i] == busca){
                        posicoes[conta] = i +1;
                        conta++;
                        e = 1;
                    }
                }
                if (e == 1){
                    cout << "\nO valor " << busca << " está no vetor, e aparece " << conta << " vezes." << endl;
                    cout << "Nas posições";
                
                    for (i = 0; i < conta; i++){
                        if (i != conta - 1){
                            cout << " " << posicoes[i];
                        } else {
                            cout << " e " << posicoes[i] << "." << endl;
                        }
                    }
                } else {
                    cout << "\nO valor " << busca << " não está no vetor." << endl;
                }
                break; 
            case 3:
                cout << "\nDigite o limite inferior do intervalo de valores  que deseja buscar." << endl;
                cin >> liminf;
                cout << "\nDigite o limite superior do intervalo de valores  que deseja buscar." << endl;
                cin >> limsup;
                
                e = 0;
                conta = 0;
                
                for (i = 0; i < TAM; i++){
                    if (numero[i] >= liminf && numero[i] <= limsup){
                        conta++;
                    }
                }
                cout << "\nOs valores do intervalo entre " << liminf << " e " << limsup << " aparecem " << conta <<  " vezes no vetor." << endl;
                break;    
        }
        
    } while (opcao = 0);

    return 0;
}


