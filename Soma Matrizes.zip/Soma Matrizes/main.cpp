/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 3 de junho de 2024, 17:08
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    const int TAM = 10;

    int mat1[TAM][TAM], mat2[TAM][TAM], mat3[TAM][TAM], lin, col;

    cout << "Digite o número de linhas das matrizes: ";
    cin >> lin;

    cout << "Digite o número de colunas das matrizes: ";
    cin >> col;
    cout << endl;

    //Preenchimento da primeira matriz
    cout << "Preenchimento da primeira matriz." << endl;
    for (int i = 0; i < lin; i++) {
        for (int j = 0; j < col; j++) {
            cout << "Digite o valor da linha " << i << " coluna " << j << " : ";
            cin >> mat1[i][j];
        }
    }
    cout << endl;

    //Preenchimento da segunda matriz
    cout << "Preenchimento da segunda matriz." << endl;
    for (int i = 0; i < lin; i++) {
        for (int j = 0; j < col; j++) {
            cout << "Digite o valor da linha " << i << " coluna " << j << " : ";
            cin >> mat2[i][j];
        }
    }
    cout << endl;

    //Soma das matrizes
    cout << "O resultado da soma das matrizes é: " << endl << endl;
    for (int i = 0; i < lin; i++) {
        for (int j = 0; j < col; j++) {
            mat3[i][j] = mat1[i][j] + mat2[i][j];
            cout << mat3[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;

    return 0;
}

