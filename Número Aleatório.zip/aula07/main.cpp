/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 26 de março de 2024, 16:04
 */

#include <time.h>
#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    
    int segredo, chute;
    
    cout << "Número Aleatório." << endl;
    
    srand (time(NULL));
    segredo = rand()%100 + 1;
    cout << "O valor é:" << segredo << endl;

    return 0;
}

