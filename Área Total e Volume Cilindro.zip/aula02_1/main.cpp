
/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo
 *
 * Created on 27 de fevereiro de 2024, 17:21
 */


/*Projeto para calcular a área total e o volume de um cilindro.*/
#include <stdio.h>

int main(){
    
    float raio, altura, area, volume;

    printf("Digite o raio do cilindro: ");
    scanf(" %f", &raio);
    printf("\nDigite a altura do cilindro: ");
    scanf(" %f", &altura);
    
    area = (2*3.14*raio*altura+2*3.14*raio*raio);
    volume = (3.14*raio*raio*altura);
    

    printf("\n\t A área do cilindro é: %.2f", area);
    printf("\n\t O volume do cilindro é: %.2f", volume);
     
  return 0;
}


