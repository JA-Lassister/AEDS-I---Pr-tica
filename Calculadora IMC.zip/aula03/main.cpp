/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo
 *
 * Created on 5 de março de 2024, 16:25
 */

/*Cálculo do índice de massa corporal de uma pessoa*/
#include <stdio.h>

int main() {
    
    float peso, altura, IMC;
    
    printf("\n\tCalculadora de índice de massa corporal (IMC)\n\n");

    printf("\tDigite seu peso em quilogramas (Kg): ");
    scanf(" %f", &peso);
    
    printf("\n\tDigite sua altura em metros (m): ");
    scanf(" %f", &altura);
    
    IMC = peso / (altura * altura);
    

    printf("\n\tSeu índice de massa corporal é: %.2f\n", IMC);
    
    if (IMC < 18.5){
        printf("\n\tVocê está abaixo do peso\n");
    } else
        if (IMC < 24.9){
            printf("\n\tVocê está no seu peso ideal\n");
        } else
            if (IMC < 29.9){
                printf("\n\tVocê está levemente acima do peso\n");
            } else
                if (IMC < 34.9){
                    printf("\n\tVocê está obeso grau 1\n");
                } else
                    if (IMC < 39.9){
                    printf("\n\tVocê está obeso grau 2\n");
                    } else 
                        printf("Você está obeso grau 3\n");
    
    return 0;
}

