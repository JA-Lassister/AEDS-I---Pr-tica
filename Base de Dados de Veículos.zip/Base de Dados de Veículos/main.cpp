/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 6 de maio de 2024, 15:58
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
#include <valarray>
#include <iomanip>
#include <math.h>

using namespace std;

/* Projeto Estatística em Base de Dados
 * 
 * O programa lê os dados a partir de um arquivo-texto e os armazena em um vetor.
 * Durante a execução, o programa oferece diversas opções de operação para o
 * usuário, apresentadas em um menu.
 * Ao final da execução, o programa escreve os dados no mesmo arquivo-texto em que
 * leu as informações inicialmente.
 * 
 */ 

const int TAM = 100;

typedef struct{
    bool valido;
    string modelo;
    string marca;
    string tipo;
    int ano;
    float km;
    string potencia;
    string fuel;
    string cambio;
    string direcao;
    string cor;
    string portas;
    string placa;
    float valor;
}Veiculo;

typedef struct{
    string tipo;
    int qtd;
}Tipos;

typedef struct{
    string fuel;
    int qtd;
}Combustivel;

int main(int argc, char** argv) {
    
    //Declaração das variáveis
    Veiculo dados[TAM];
    Tipos tipos[TAM];
    Combustivel fuels[TAM];
    int i, qtd, qtdv, opcao, j, opbusca, e, remover, qtdtp, qtdc, qtd5;
    string modelo, busca, placa;
    float valinf, valsup, soma;
    
    //Abertura do arquivo
    ifstream arquivo("BD_veiculos.txt");
    
    if (!arquivo.is_open()){
        cout << "Erro: Arquivo inexistente." << endl;
        return 1;
    }
    
    //Transposição do arquivo para o vetor
    i = 0;
    arquivo >> modelo;
    while(modelo != "Fim" && qtd <= TAM){
        dados[i].modelo = modelo;
        arquivo >> dados[i].marca
                >> dados[i].tipo
                >> dados[i].ano
                >> dados[i].km
                >> dados[i].potencia
                >> dados[i].fuel
                >> dados[i].cambio
                >> dados[i].direcao
                >> dados[i].cor
                >> dados[i].portas
                >> dados[i].placa
                >> dados[i].valor;
        dados[i].valido = true;
        i++;
        qtd++;
        arquivo >> modelo;
    }
    
    qtd--;
    qtdv = qtd + 1;
    
    arquivo.close();
    
    cout << setprecision(2) << fixed;
    
    //Operações
    do{
        cout << "Digite o número refente à operação que deseja realizar." << endl;
        cout << " 1 - Visualizar base de dados." << endl;
        cout << " 2 - Incluir um novo veículo na base de dados." << endl;
        cout << " 3 - Buscar um veículo na base de dados." << endl;
        cout << " 4 - Obter relatório dos veículos na base de daos." << endl;
        cout << " 0 - Sair" << endl;
        cin >> opcao;
        
        switch(opcao){
            //Encerrar programa
            case 0:
                break;
            //Visualizar base de dados
            case 1:
                cout << "\n";
                for(i = 0; i <= qtd; i++){
                    if(dados[i].valido == true){
                        cout << " > " << dados[i].modelo << " "
                                << dados[i].marca << " "
                                << dados[i].tipo << " "
                                << dados[i].ano << " "
                                << dados[i].km << " "
                                << dados[i].potencia << " "
                                << dados[i].fuel << " "
                                << dados[i].cambio << " "
                                << dados[i].direcao << " "
                                << dados[i].cor << " "
                                << dados[i].portas << " "
                                << dados[i].placa << " "
                                << dados[i].valor << " "
                                << endl;
                    }
                }
                cout << endl;
                break;
            //Incluir um novo veículo na base de dados.    
            case 2:
                if(qtdv == TAM){
                    cout << "A base de dados está cheia. Não é possível adicionar um novo veículo." << endl;
                } else {
                    qtdv++;
                    if(qtdv > qtd){
                        qtd = qtdv;
                    }
                    j = qtd;
                    for(i = 0; i <= qtd; i++){
                        if(dados[i].valido == false){
                            j = i;
                            dados[i].valido = true;
                            i = qtd + 1;
                        }
                    }
                    cout << "Digite os dados do veículo." << endl;
                    cout << "Modelo: ";
                    cin >> dados[j].modelo;
                    cout << "Marca: ";
                    cin >> dados[j].marca;
                    cout << "Tipo: ";
                    cin >> dados[j].tipo;
                    cout << "Ano: ";
                    cin >> dados[j].ano;
                    cout << "Quilometragem: ";
                    cin >> dados[j].km;
                    cout << "Potência do motor: ";
                    cin >> dados[j].potencia;
                    cout << "Combustível: ";
                    cin >> dados[j].fuel;
                    cout << "Câmbio: ";
                    cin >> dados[j].cambio;
                    cout << "Direção: ";
                    cin >> dados[j].direcao;
                    cout << "Cor: ";
                    cin >> dados[j].cor;
                    cout << "Quantidade de portas: ";
                    cin >> dados[j].portas;
                    cout << "Placa: ";
                    cin >> dados[j].placa;
                    cout << "Valor: ";
                    cin >> dados[j].valor;
                    cout << endl;
                }
                break;
            //Buscar veículos (e apagar pela placa)
            case 3:
                cout << "\nDigite o número referente ao tipo de busca que deseja realizar." << endl;
                cout << " 1 - Buscar por placa." << endl;
                cout << " 2 - Buscar por tipo." << endl;
                cout << " 3 - Buscar por câmbio." << endl;
                cout << " 4 - Buscar veículos em determinada faixa de valor." << endl;
                cin >> opbusca;
                
                switch(opbusca){
                    //Busca pela placa
                    case 1:
                        cout << "\nDigite a placa do veículo que deseja buscar: " << endl;
                        cin >> busca;
                        cout << "\n";
                        e = 0;
                        for(i = 0; i <= qtd && e == 0; i++){
                            if(busca == dados[i].placa && dados[i].valido == true){
                                cout << " > " << dados[i].modelo << " "
                                        << dados[i].marca << " "
                                        << dados[i].tipo << " "
                                        << dados[i].ano << " "
                                        << dados[i].km << " "
                                        << dados[i].potencia << " "
                                        << dados[i].fuel << " "
                                        << dados[i].cambio << " "
                                        << dados[i].direcao << " "
                                        << dados[i].cor << " "
                                        << dados[i].portas << " "
                                        << dados[i].placa << " "
                                        << dados[i].valor << " "
                                        << endl << endl;
                                e = 1;
                            }
                        }
                        if(e == 0){
                            cout << "Veículo não está na base de dados." << endl << endl;
                        }
                        //Remover veículo da base de dados
                        if(e == 1){
                            cout << "Deseja excluir o veículo da base de dados?" << endl;
                            cout << "Digite 1 para Sim" << endl;
                            cin >> remover;
                            
                            if(remover == 1){
                                cout << "Tem certeza? Uma vez excluído não é possível recuperar as informações." << endl;
                                cout << "Digite 1 para Sim." << endl;
                                cin >> remover;
                            }
                            
                            switch(remover){
                                case 1:
                                    dados[i - 1].valido = false;
                                    qtdv--;
                                    break;
                                default:
                                    break;
                            }
                            
                        }
                        cout << endl;
                        break;
                    //Busca pelo tipo    
                    case 2:
                        cout << "\nDigite o tipo de veículo que deseja buscar." << endl;
                        cin >> busca;
                        cout << "\n";
                        e = 0;
                        for(i = 0; i <= qtd; i++){
                            if(busca == dados[i].tipo && dados[i].valido == true){
                                cout << " > " << dados[i].modelo << " "
                                        << dados[i].marca << " "
                                        << dados[i].tipo << " "
                                        << dados[i].ano << " "
                                        << dados[i].km << " "
                                        << dados[i].potencia << " "
                                        << dados[i].fuel << " "
                                        << dados[i].cambio << " "
                                        << dados[i].direcao << " "
                                        << dados[i].cor << " "
                                        << dados[i].portas << " "
                                        << dados[i].placa << " "
                                        << dados[i].valor << " "
                                        << endl;
                                e = 1;
                            }
                        }
                        if(e == 0){
                            cout << "Não há veículos desse tipo na base de dados." << endl;
                        }
                        cout << endl;
                        
                        break;
                    //Busca pelo câmbio    
                    case 3:
                        cout << "\nDigite o câmbio dos veículos que deseja buscar." << endl;
                        cin >> busca;
                        cout << "\n";
                        e = 0;
                        for(i = 0; i <= qtd; i++){
                            if(busca == dados[i].cambio && dados[i].valido == true){
                                cout << " > " << dados[i].modelo << " "
                                        << dados[i].marca << " "
                                        << dados[i].tipo << " "
                                        << dados[i].ano << " "
                                        << dados[i].km << " "
                                        << dados[i].potencia << " "
                                        << dados[i].fuel << " "
                                        << dados[i].cambio << " "
                                        << dados[i].direcao << " "
                                        << dados[i].cor << " "
                                        << dados[i].portas << " "
                                        << dados[i].placa << " "
                                        << dados[i].valor << " "
                                        << endl;
                                e = 1;
                            }
                        }
                        if(e == 0){
                            cout << "Não há veículos com esse câmbio na base de dados." << endl;
                        }
                        cout << endl;
                        
                        break;
                    //Busca pela faixa de valor    
                    case 4:
                        cout << "\nDigite o valor mínimo que deseja buscar: ";
                        cin >> valinf;
                        cout << "\nDigite o valor máximo que deseja busca: ";
                        cin >> valsup;
                        cout << "\n" << endl;
                        e = 0;
                        for(i = 0; i <= qtd; i++){
                            if(dados[i].valor >= valinf && dados[i].valor <= valsup && dados[i].valido == true){
                                cout << " > " << dados[i].modelo << " "
                                        << dados[i].marca << " "
                                        << dados[i].tipo << " "
                                        << dados[i].ano << " "
                                        << dados[i].km << " "
                                        << dados[i].potencia << " "
                                        << dados[i].fuel << " "
                                        << dados[i].cambio << " "
                                        << dados[i].direcao << " "
                                        << dados[i].cor << " "
                                        << dados[i].portas << " "
                                        << dados[i].placa << " "
                                        << dados[i].valor << " "
                                        << endl;
                                e = 1;
                            }
                        }
                        if(e == 0){
                            cout << "Não há veículos desse tipo na base de dados." << endl;
                        }
                        cout << endl;
                        
                        break;
                }
                break;
            //Obter relatório da base de dados
            case 4:
                if(qtdv != 0){
                    cout << "\nDigite o número referente ao tipo de relatório que deseja obter." << endl;
                    cout << " 1 - Porcentagem de veículos pelo tipo." << endl;
                    cout << " 2 - Porcentagem de veículos pelo combustível." << endl;
                    cout << " 3 - Placa e valor do mais barato entre os veículos com potência do motor 1.0." << endl;
                    cout << " 4 - Placa e valor do veículo mais caro com direção hidráulica e câmbio automático." << endl;
                    cout << " 5 - Quantidade e média de quilometragem dos veículos com 5 anos ou mais." << endl;
                    cin >> opbusca;

                    switch(opbusca){
                        //Porcentagem por tipo
                        case 1:
                            tipos[0].tipo = dados[0].tipo;
                            tipos[0].qtd = 1;
                            qtdtp = 1;

                            for(i = 1; i <= qtd; i++){
                                e = 0;
                                for(j = 0; j <= qtd; j++){
                                    if(dados[i].tipo == tipos[j].tipo && dados[i].valido == true){
                                        tipos[j].qtd++;
                                        e = 1;
                                    }
                                }
                                if(e == 0 && dados[i].valido == true){
                                    tipos[qtdtp].tipo = dados[i].tipo;
                                    tipos[qtdtp].qtd = 1;
                                    qtdtp++;
                                }
                            }

                            cout << "\nPorcentagem de veículos pelo tipo:" << endl;
                            for(i = 0; i < qtdtp; i++){
                                cout << " " << tipos[i].tipo << " " << (float) tipos[i].qtd * 100 / qtdv << "%." << endl;
                            }
                            cout << endl;
                            break;
                        //Porcentagem por combustível   
                        case 2:
                            fuels[0].fuel = dados[0].fuel;
                            fuels[0].qtd = 1;
                            qtdc = 1;

                            for(i = 1; i<= qtd; i++){
                                e = 0;
                                for(j = 0; j <= qtd; j++){
                                    if(dados[i].fuel == fuels[j].fuel && dados[i].valido == true){
                                        fuels[j].qtd++;
                                        e = 1;
                                    }
                                }
                                if(e == 0 && dados[i].valido == true){
                                    fuels[qtdc].fuel = dados[i].fuel;
                                    fuels[qtdc].qtd = 1;
                                    qtdc++;
                                }
                            }

                            cout << "\nPorcentagem de veículos pelo combustível:" << endl;
                            for(i = 0; i < qtdc; i++){
                                cout << " " << fuels[i].fuel << " " << (float) fuels[i].qtd * 100 / qtdv << "%." << endl;
                            }
                            cout << endl;
                            break;
                        //Placa e valor do mais barato de potância 1.0 e valor da prestação
                        case 3:
                            cout << "\n";
                            e = 0;
                            for(i = 0; i <= qtd && e == 0; i++){
                                if(dados[i].potencia == "1.0" && dados[i].valido == true){
                                    valinf = dados[i].valor;
                                    placa = dados[i].placa;
                                    e = 1;
                                }
                            }
                            for(i; i <= qtd; i++){
                                if(dados[i].potencia == "1.0" && dados[i].valor < valinf && dados[i].valido == true){
                                    valinf = dados[i].valor;
                                    placa = dados[i].placa;
                                }
                            }

                            if(e == 0){
                                cout << "Não há veículos de potência do motor 1.0 na base de dados." << endl;
                            } else{                        
                                cout << "Placa: " << placa << " Valor: R$" << valinf << endl;

                                cout << "O valor da prestação do financiamento em 60 vezes para este veículo é R$";
                                cout << pow(1 + 1.13 / 100, 60) * valinf / 60 << endl;
                            }
                            cout << endl;
                            break;
                        //Placa e valor mais caro com direção hidráulica e câmbio automático e valor do seguro
                        case 4:
                            cout << "\n";
                            e = 0;
                            for(i = 0; i <= qtd && e == 0; i++){
                                if(dados[i].direcao == "Hidráulica" && dados[i].cambio == "Automático" && dados[i].valido == true){
                                    valsup = dados[i].valor;
                                    placa = dados[i].placa;
                                    e = 1;
                                }
                            }
                            for(i; i <= qtd; i++){
                                if(dados[i].direcao == "Hidráulica" && dados[i].cambio == "Automático" && dados[i].valor > valsup && dados[i].valido == true){
                                    valsup = dados[i].valor;
                                    placa = dados[i].placa;
                                }
                            }

                            if(e == 0){
                                cout << "Não há veículos com direção hidráulica e câmbio automático na base de dados." << endl;
                            } else{
                                cout << "Placa: " << placa << " Valor: R$" << valsup << endl;

                                cout << "O valor estimado do seguro do veículo é: R$" << valsup * 6.6 / 100;
                                cout << endl;
                            }
                            cout << endl;
                            break;
                        //Quantidade e média de quilometragem com 5 anos ou mais
                        case 5:
                            soma = 0;
                            qtd5 = 0;
                            for(i = 0; i <= qtd; i++){
                                if(dados[i].ano <= 2019 && dados[i].valido == true){
                                    soma = soma + dados[i].km;
                                    qtd5++;
                                }
                            }

                            cout << "\nQuantidade de veículos com 5 anos ou mais: " << qtd5 << endl;
                            cout << "Média da quilometragem dos veículos com 5 anos ou mais: " << soma / qtd5 << "km."<< endl << endl;
                            break;
                    }
                } else {
                    cout << "\nA base de dados está vazia. Não é possível obter relatório." << endl;
                }
                    break;
        }
    } while(opcao != 0);
    
    //Reescrita do arquivo
    ofstream arquivo1("BD_veiculos.txt");
    
    if (!arquivo1.is_open()){
        cout << "Erro: Arquivo inexistente." << endl;
        return 1;
    }
    
    for(i = 0; i <= qtd; i++){
        if(dados[i].valido == true){
            arquivo1 << dados[i].modelo << " "
                    << dados[i].marca << " "
                    << dados[i].tipo << " "
                    << dados[i].ano << " "
                    << dados[i].km << " "
                    << dados[i].potencia << " "
                    << dados[i].fuel << " "
                    << dados[i].cambio << " "
                    << dados[i].direcao << " "
                    << dados[i].cor << " "
                    <<  dados[i].portas << " "
                    << dados[i].placa << " "
                    << dados[i].valor << " "
                    << endl;
        }
    }
    arquivo1 << "Fim";
    
    arquivo1.close();

    return 0;
}

