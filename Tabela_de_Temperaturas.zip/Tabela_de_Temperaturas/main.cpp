/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 11 de março de 2024, 16:49
 */

#include <iostream>

using namespace std;

int main(){

    float temperaturaF;
    int temperaturaC;
    
    temperaturaC = 0;      
    
    cout<<"\t_____________________________________________________________\n";
    cout<<"\t|\n";
    cout<<"\t|\n";
    
    while(temperaturaC < 101){
        temperaturaF = temperaturaC*1.8+32;
        
        cout<<"\t| Temperatura em Celsius: "<<temperaturaC<<" Temperatura em Fahrenheit: "<<temperaturaF<<" \n";
        cout<<"\t|\n";
        
        temperaturaC = temperaturaC+5;
    }
    
    cout<<"\t|";
    cout<<"____________________________________________________________\n";
    
    return 0;
}

