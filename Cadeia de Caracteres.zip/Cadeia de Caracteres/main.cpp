/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 23 de abril de 2024, 11:56
 */

#include <cstdlib>
#include <stdio.h>

using namespace std;

/*Código para manipulação de caracteres em um vetor
 * 
 */
int main(int argc, char** argv) {
    
    //Declaração das variáveis
    char nome[31], sobrenome[31], nomecompleto[61], busca[61];
    int i, j, opcao;
    
    //Iniciação dos vetores "nome" e "sobrenome"
    nome[0] = 'J';
    nome[1] = 'o';
    nome[2] = 'a';
    nome[3] = 'o';
    nome[4] = ' ';
    nome[5] = 'A';
    nome[6] = 'n';
    nome[7] = 't';
    nome[8] = 'o';
    nome[9] = 'n';
    nome[10] = 'i';
    nome[11] = 'o';
    nome[12] = '\0';

    printf("\n Nome: %s.\n", nome);

    sobrenome[0] = 'L';
    sobrenome[1] = 'a';
    sobrenome[2] = 's';
    sobrenome[3] = 's';
    sobrenome[4] = 'i';
    sobrenome[5] = 's';
    sobrenome[6] = 't';
    sobrenome[7] = 'e';
    sobrenome[8] = 'r';
    sobrenome[9] = ' ';
    sobrenome[10] = 'M';
    sobrenome[11] = 'e';
    sobrenome[12] = 'l';
    sobrenome[13] = 'o';
    sobrenome[14] = '\0';

    printf("\n Sobrenome: %s.\n", sobrenome);
    
    //Construção do vetor "nomecompleto"
    for(i = 0; nome[i] != '\0'; i++){
        nomecompleto[i] = nome[i];
    }
    nomecompleto[i] = ' ';
    j = i + 1;
    for(i = 0; sobrenome[i] != '\0'; i++){
        nomecompleto[j] = sobrenome[i];
        j++;
    }
    nomecompleto[j] = '\0';
    
    printf("\n Nome completo: %s.\n", nomecompleto);
    
    //Colocar os caracteres do nome completo em maíusculo
    for(i = 0; nomecompleto[i] != '\0'; i++){
        if(nomecompleto[i] > 96 && nomecompleto[i] != 32){
            nomecompleto[i] = nomecompleto[i] - 32;
        }
    }
    
    printf("\n Nome completo maiúsculo: %s.\n", nomecompleto);
    
    //Colocar os caracteres do nome completo em minúsculo (exceto as primeiras letras)
    for(i = 1; nomecompleto[i] != '\0'; i++){
        j = i - 1;
        if(nomecompleto[j] != 32 && nomecompleto[i] != 32){
            nomecompleto[i] = nomecompleto[i] + 32;
        }
    }
    
    printf("\n Nome completo: %s.\n", nomecompleto);
    
    //Retirar os espaços do nome completo
    for(i = 0; nomecompleto[i] != '\0'; i++){
        if(nomecompleto[i] == ' '){
            for(j = i; nomecompleto[j] != 0; j++){
                nomecompleto[j] = nomecompleto[j + 1];
            }
        }
    }
    
    printf("\n Nome completo (sem espaços): %s.\n", nomecompleto);
    
    //Procurar um nome dentro do nome completo
    printf("\n Digite o nome que deseja procurar: ");
    scanf("%s", &busca);
                
    int e = 0;
                
    for (i = 0; nomecompleto[i] != '\0'; i++){
        if (nomecompleto[i] == busca[0]){
            for(j = 1; busca[j] != '\0' && nomecompleto[i + j] != '\0'; j++){
                e = 1;
                if (nomecompleto[i + j] != busca[j]){
                    e = 0;
                }
            }
        }
    }
    if(e == 1){
        printf("\n O nome está no vetor.\n");
    }
    if(e == 0){
        printf("\n O nome não está no vetor\n");
    }
    
    return 0;
}


