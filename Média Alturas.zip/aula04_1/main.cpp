/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 11 de março de 2024, 16:49
 */

#include <iostream>

using namespace std;

int main(){

    float altura, media;
    int i;
    
    media = 0;
    i = 0;   
    
    while(i < 10){
        cout<<"Digite a "<<i+1<<"ª altura: ";
        cin>>altura;
        while(altura < 0 || altura == 0){
            cout<<"Valor inválido. Digite novamente: ";
            cin>>altura;
        }
        
        media = media+altura;
        i = i+1;
    }
    
    cout<<"\nA média das alturas é: "<<media/i<<"";
    
    return 0;
}

