/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 25 de março de 2024, 16:07
 */

#include <cstdlib>
#include <stdio.h>

using namespace std;

/*
 * 
 */
int main() {         
    
    printf("\n\tTipos de Variáveis e Alocação de Memória \n\n");
    
    int variavelint = 50;  
    
    printf("\tVariável Inteira: \n");
    printf("\t\tValor Armazenado: %d\n", variavelint);
    printf("\t\t Endereço na Memória: %p\n", &variavelint);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(int));
    
    float variavelfloat = 50; 
    
    printf("\tVariável Float: \n");
    printf("\t\tValor Armazenado: %f\n", variavelfloat);
    printf("\t\t Endereço na Memória: %p\n", &variavelfloat);
    printf("\t\tQuantidade em bytes: %li\n\n", sizeof(float));
    
    unsigned char codigoASCII = 0;
    
    printf("\tTabela ASCII: \n");
    
    codigoASCII = 0;
    while ( codigoASCII < 255){
        printf("\t\tCaracter: %c", codigoASCII);
        printf("\t\tCódigo: %d\n", codigoASCII);
        codigoASCII++;
    }
     
    return 0;
}

