/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassiter Melo 2024.1.08.027
*
 * Created on 9 de abril de 2024, 16:22
 */

#include <time.h>
#include <iostream>

using namespace std;

/*Código de Manipulação de Vetores
 
 O código tem como objetivo permitir ao usuário realizar diversas operações em
 um vetor que contém 1000 valores inteiros gerados aleatoriamente variando de 100 a 200.
 As opções de operações são apresentadas em um menu e podem ser realizadas quantas vezes o usuário desejar.
 Sendo elas: 
 1- Buscar um valor no vetor e a posição de sua primeira ocorrência.
 2- Buscar um valor no vetor, seu número de ocorrências e as posições de ocorrência.
 3- Buscar a quantidade de ocorrências de determinado intevalo.
 4- Inverter os valores do vetor.
 5- Excluir um determinado valor do vetor.
 6- Excluir todos os valores repetidos.
 
 O código utilizar de um comando "switch" dentro de um "do while" para apresentar
 as opções de operações e permitir que o usuário escolha qual deseja realizar, quantas vezes quiser.
 
 As operações são realizadas atráves de uma série de comandos "for" e "if" que
 checam os valores do vetor e se estes cumprem com os requisitos da operação,
 no caso das operações que excluem valores do vetor, essa exclusão é feita através
 de comandos "for" que deslocam os demais valores para a esquerda e alteram a 
 quantidade de posições a serem mostradas no vetor.*/

int main() {
    
    //Declaração das variáveis
    const int TAM = 1000;
    int i, numero[TAM], opcao, busca, e, posicoes[TAM], conta, liminf, limsup, j, aux, qtd, k;
    
    opcao = 0;
    qtd = TAM;
    
    //Armazenamento de valores aleatórios no vetor
    srand (time(NULL));
    
    for (i = 0; i < TAM; i++){
        numero[i] = 100 + rand() % 101;
        cout << i << "\t" << numero[i] << endl;
    }
    
    //Opções de operação
    do {
        cout << "\nDigite o número referente ao tipo de manipulação que deseja realizar." << endl << endl;
        cout << " 1 - Verificar se um valor está no vetor e sua primeira posição." << endl;
        cout << " 2 - Verificar se um está no vetor e em quais posições." << endl;
        cout << " 3 - Verificar quantas vezes os valores de um determinado intervalo aparecem no vetor." << endl;
        cout << " 4 - Inverter os valores do vetor." << endl;
        cout << " 5 - Retirar do vetor todas as ocorrências de um valor." << endl;
        cout << " 6 - Retirar de um vetor todos os valores repetidos." << endl;
        cout << "\n\t\t\t\t\t\t\t\t0 - Encerrar programa." << endl;
        cin >> opcao;
        switch (opcao){
            case 0:
                cout << "\nPrograma finalizado." << endl;
                break;
            //Busca por um valor e sua primeira posição
            case 1:
                cout << "\nDigite o valor que deseja buscar." << endl;
                cin >> busca; 
                
                e = 0;
                
                for (i = 0; e == 0 && i < qtd; i++){
                    if (numero[i] == busca){
                        e = 1;
                    }
                }
                if (e == 1){
                    cout << "\nO valor " << busca << " está no vetor, e aparece pela primeira vez na posição " << i - 1 << "." << endl;
                } else {
                    cout << "\nO valor " << busca << " não está no vetor." << endl;
                }
                break;
            //Busca por um valor e todas as suas posições
            case 2:
                cout << "\nDigite o valor que deseja buscar." << endl;
                cin >> busca;
                
                e = 0;
                conta = 0;
                
                for (i = 0; i < qtd; i++){
                    if (numero[i] == busca){
                        posicoes[conta] = i;
                        conta++;
                        e = 1;
                    }
                }
                if (e == 1){
                    cout << "\nO valor " << busca << " está no vetor, e aparece " << conta << " vezes." << endl;
                    cout << "Nas posições";
                
                    for (i = 0; i < conta; i++){
                        if (i != conta - 1){
                            cout << " " << posicoes[i];
                        } else {
                            cout << " e " << posicoes[i] << "." << endl;
                        }
                    }
                } else {
                    cout << "\nO valor " << busca << " não está no vetor." << endl;
                }
                break;
            //Busca por um intervalo de valores e contagem das posições
            case 3:
                cout << "\nDigite o limite inferior do intervalo de valores  que deseja buscar." << endl;
                cin >> liminf;
                cout << "\nDigite o limite superior do intervalo de valores  que deseja buscar." << endl;
                cin >> limsup;
                
                e = 0;
                conta = 0;
                
                for (i = 0; i < qtd; i++){
                    if (numero[i] >= liminf && numero[i] <= limsup){
                        conta++;
                    }
                }                
                cout << "\nOs valores do intervalo entre " << liminf << " e " << limsup << " aparecem " << conta <<  " vezes no vetor." << endl;
                break;
            //Inversão dos valores do vetor
            case 4:
                cout << endl;
                j = qtd - 1;
                for (i = 0; i < qtd / 2; i++){
                    aux = numero[i];
                    numero[i] = numero[j];
                    numero[j] = aux;
                    j--;
                }
                for (i = 0; i < qtd; i++){
                    cout << i << "\t" << numero[i] << endl;
                }
                break;
            //Retirar um valor específico do vetor
            case 5:
                cout << "\nDigite o valor que deseja retirar do vetor." << endl;
                cin >> busca;
                cout << endl;
                for (i = 0; i < qtd; i++){
                    if (numero[i] == busca){
                        qtd--;
                        for (i; i < qtd; i++){
                            j = i + 1;
                            numero[i] = numero[j];
                        }  
                    i = 0;
                    }        
                }
                for (i = 0; i < qtd; i++){
                    cout << i << "\t" << numero[i] << endl;
                }
                break;
            //Retirar todos os valores repetidos do vetor
            case 6:
                cout << endl;
                for (i = 0; i < qtd; i++){
                    for (j = i + 1; j < qtd; j++){
                        if (numero[i] == numero[j]){
                            for (k = j + 1; k != qtd; k++){                                
                                numero[k - 1] = numero[k];
                            }
                            qtd--;
                            j--;
                        }
                    }    
                }
                for (i = 0; i < qtd; i++){
                    cout << i << "\t" << numero[i] << endl;
                }
                break;
            default:
                cout << "Valor inválido." << endl;
        }
        
    } while (opcao != 0);

    return 0;
}


