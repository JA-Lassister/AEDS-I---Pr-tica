/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 27 de março de 2024, 12:34
 */

#include <time.h>
#include <iostream>
#include <iomanip>

using namespace std;

/* Cálculo da média entre 1000 valores de alturas entre 1,5m e 2,3m.
 * 
 * O código tem como objetivo calcular a média de 1000 valores aleatórios de alturas, 
 * que variam entre 1,5m e 2,3m, gerados através da função "rand".
 * Além disso, o código através de uma série de condicionais, consegue determinar o menor e maior valor, 
 * como também a porcentagem de valores acima de 2,0m. 
 */
int main() {
    
    srand (time(NULL));
    
//Declaração das variáveis.
    
    int i;
    float p, altura, menor, maior, somatorio, media, porcentagem;    
    
    somatorio = 0;
    p = 0;
    
//Primeira altura aletória

    altura = rand()%(230 + 1 - 150) + 150;
    altura = altura / 100;
    i = 1;
    menor = altura;
    maior = altura;
    
//Restante das alturas aleatórias e somátório das alturas geradas.
        
    while (i != 1000){           
        altura = rand()%(230 + 1 - 150) + 150;	
        i++;
	altura = altura / 100;
        somatorio = somatorio + altura;
        
/*Condicionais para determinar a quantidade de pessoas maiores que 2,0,
* e a maior e menor altura.
*/       
        
	if (altura > 2.0){
	    p++;
	}
	if (altura > maior){
	    maior = altura;
	}
	else
	if (altura < menor){
	    menor = altura;
	}
	
    }
    
//Cálculo da média e porcentagem.

    media = somatorio / i;
    porcentagem = p * 100 / i;
    
//Impressão dos valores.
    
    cout << "Gerador de 1000 alturas aleatórias.\n" << endl;
    cout << fixed << setprecision(2);
    cout << "A média das alturas é: " << media << "m" << endl;
    cout << "\nA menor altura é: " << menor << "m""\t\tA maior altura é: " << maior << "m" << endl;
    cout << "\nA porcentagem de pessoas maiores de 2,0 metros é: " << porcentagem << "%";
    
    return 0;
}

