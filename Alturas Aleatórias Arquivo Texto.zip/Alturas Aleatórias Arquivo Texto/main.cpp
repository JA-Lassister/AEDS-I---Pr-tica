/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 26 de março de 2024, 16:04
 */

#include <time.h>
#include <iostream>
#include <fstream>

using namespace std;

/*
 * 
 */
int main() {
    
    srand (time(NULL));
    
    int i, qtd;
    float lmenor, lmaior, altura;
    ofstream arquivo("saida.txt");
    
    if (!arquivo.is_open()){
        cout << "Erro: arquivo não existe." << endl;
        return 1;
    }
    
    i = 0;
    lmenor = 1.5;
    lmaior = 2.3;
    
    cout << "Digite a quantidade de alturas à serem geradas:" << endl;
    cin >> qtd;
    
    arquivo << qtd << endl;
    arquivo << "Limite Inferior: " << lmenor << "\tLimite Superior: " << lmaior << endl;
        
    while (i < qtd){           
        altura = rand()%(230 + 1 - 150) + 150;	
        i++;
	altura = altura / 100;
        arquivo << altura << endl;       
    }
    
    arquivo.close();
    
    cout << "Informações atribuídas ao arquivo." << endl;
          
    return 0;
}

