/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 1 de abril de 2024, 17:37
 */

#include <iostream>
#include <fstream>
#include <valarray>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    int opcao;
    float lado1, lado2, altura, raio;
    string objeto;
    ofstream arquivo ("cenagrafica.txt");
    
    if (!arquivo.is_open()){
        cout << "\nErro: Arquivo inexistente." << endl;
        return 1;
    }    
    
    do {
        
    cout << "\nDigite o número referente ao objeto desejado" << endl;
    cout << " 1-Cubo | 2-Quadrado | 3-Paralelepípedo | 4-Retângulo | 5-Pirâmide |"
            " 6-Triângulo | 7-Cilindro | 8-Esfera | 9-Círculo | 10-Cone | 0 -Sair" << endl;
    cin >> opcao;
        
    switch (opcao){
        case 0:
            arquivo << "Fim" << endl;
            cout << "\nPrograma finalizado" << endl;            
            break;
        case 1:
            cout << "\nDigite a medida do lado do Cubo" << endl;
            cin >> lado1;
            arquivo << "Cubo " << lado1 << endl;
            break;
        case 2:
            cout << "\nDigite a medida do lado do Quadrado" << endl;
            cin >> lado1;
            arquivo << "Quadrado " << lado1 << endl;
            break;
        case 3:            
            cout << "\nDigite a medida dos lados e altura do Paralelepípedo" << endl;
            cin >> lado1 >> lado2 >> altura;
            arquivo << "Paralelepípedo " << lado1 << " " << lado2 << " " << altura << endl;
            break;
        case 4:
            cout << "\nDigite a medida dos lados do Retângulo" << endl;
            cin >> lado1 >> lado2;
            arquivo << "Retângulo " << lado1 << " " << lado2 << endl;
            break;
        case 5:
            cout << "\nDigite a medida do lado e altura da Pirâmide" << endl;
            cin >> lado1 >> altura;
            arquivo << "Pirâmide " << lado1 << " " << altura << endl;
            break;
        case 6:
            cout << "\nDigite a medida do lado e altura do Triângulo" << endl;
            cin >> lado1 >> altura;
            arquivo << "Triângulo " << lado1 << " " << altura << endl;
            break;
        case 7:
            cout << "\nDigite a medida do raio e altura do Cilindro" << endl;
            cin >> raio >> altura;
            arquivo << "Cilindro " << raio << " " << altura << endl;
            break;
        case 8:
            cout << "\nDigite a medida do raio da Esfera" << endl;
            cin >> raio;
            arquivo << "Esfera " << raio << endl;
            break;
        case 9:
            cout << "\nDigite a medida do raio do Círculo" << endl;
            cin >> raio;
            arquivo << "Círculo " << raio << endl;
            break;
        case 10:
            cout << "\nDigite a medida do raio e altura do Cone" << endl;
            cin >> raio >> altura;
            arquivo << "Cone " << raio << " " << altura << endl;
            break;
        default: cout << "\nOpção Inválida." << endl;    
    }
    
    } while (opcao != 0);     
            
    
    return 0;
}

