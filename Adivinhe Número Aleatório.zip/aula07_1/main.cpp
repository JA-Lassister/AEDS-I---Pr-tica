/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 26 de março de 2024, 16:04
 */

#include <time.h>
#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    
    int segredo, chute, tentativa;
    
    srand (time(NULL));
    segredo = rand()%100 + 1;
    
    cout << "\tAdivinhe o Número" << endl;
    
    cout << "\nDigite um número de 1 a 100:";
    cin >> chute;    
    
    tentativa = 1;
    
    while (chute != segredo){
        cout << "\nErrou!";
        if (chute < segredo){
            cout << "\n"<< chute <<" é menor que o número." << endl;
            cout << "Tente novamente:";
            tentativa++;
        }
        else{
            cout << "\n"<< chute <<" é maior que o número." << endl;
            cout << "Tente novamente:";
            tentativa++;
        }
        cin >> chute;
                   
    }     
    
    cout << "\nParabéns" << endl;
    cout << "O número é " << segredo << endl;
    cout << "\nNúmero de tentativas: " << tentativa << endl;


    return 0;
}

