/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 11 de março de 2024, 16:49
 */

#include <iostream>

using namespace std;

int main(){

    float altura, soma, media;
    int n;
    
    soma = 0;
    n = 0;   
    
    cout << "Digite a "<< n + 1 <<"ª altura: ";
    cin >> altura;
    soma = soma + altura;
    while (altura > 0){
        cout << "Digite a "<< n + 1 <<"ª altura: ";
        cin >> altura;     
               
        soma = soma + altura;
        n = n + 1;
    }
    
    if (n != 0){
    media = soma / n;
    
    cout << "\nA média das alturas é: "<< media <<"";
    } else
        cout << "Valor inválido";
    
    return 0;
}

