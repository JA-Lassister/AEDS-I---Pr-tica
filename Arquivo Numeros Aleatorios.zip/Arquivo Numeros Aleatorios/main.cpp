/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 20 de maio de 2024, 16:32
 */

#include <cstdlib>
#include <iostream>
#include <time.h>
#include <fstream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    srand (time(NULL));
    
    const int TAM = 100000;
    
    int vetor[TAM];
    
    for(int i = 0; i < TAM; i++){
        vetor[i] = -1;
    }
    
    int j = 0;
    for(int i = 0; i < TAM; i++){
        int k = rand()%TAM + 1;
        if(j + k >= TAM){
            j = (j + k)%TAM;
        } else
            j = j + k;
        if(vetor[j] == -1){
            vetor[j] = i;
        } else
            while(vetor[j] != -1){
                j++;
                if(j >= TAM){
                    j = (j + j)%TAM;
                }
            }
        vetor[j] = i;
    }
    
    ofstream arquivo("desordenado.txt");
    
    if (!arquivo.is_open()){
        cout << "Erro. Arquivo inexistente." << endl;
        return 1;
    }
    
    for(int i = 0; i < TAM; i++){
        arquivo << vetor[i] << endl;
    }
    
    arquivo.close();
    
    return 0;
}

