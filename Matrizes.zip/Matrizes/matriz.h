/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   matriz.h
 * Author: 2024.1.08.027
 *
 * Created on 18 de junho de 2024, 11:25
 */

#ifndef MATRIZ_H
#define MATRIZ_H

#define TAM 128

typedef int TMatriz[TAM][TAM];

int soma(TMatriz A, int nlinA, int ncolA, TMatriz B, int nlinB, int ncolB, TMatriz C, int *nlinC, int *ncolC);
int multiplicacao(TMatriz A, int nlinA, int ncolA, TMatriz B, int nlinB, int ncolB, TMatriz C, int *nlinC, int *ncolC);
void transposta (TMatriz A, int nlinA, int ncolA, TMatriz B, int *nlinB, int *ncolB);
float media (TMatriz A, int nlinA, int ncolA);




#endif /* MATRIZ_H */

