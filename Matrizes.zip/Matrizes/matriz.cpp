#include <iostream>
#include "matriz.h"

using namespace std;

/*
 * Função para somar duas matrizes e guardar os valores em uma terceira matriz.
 * Parâmetros:
 *  A, é o endereço da primeira matriz.
 *  nlinA, é o número de linhas da primeira matriz.
 *  ncolA, é o número de colunas da primeira matriz.
 *  B, é o endereço da segunda matriz.
 *  nlinB, é o número de linhas da segunda matriz.
 *  ncolB, é o número de colunas da segunda matriz.
 *  C, é o endereço da terceira matriz.
 *  *nlinC, é o endereço do número de linhas da primeira matriz.
 *  *ncolC, é o endereço do número de colunas da primeira matriz.
 * Retorno:
 *  0, para execução bem suscedida.
 *  1, para quando não é possível executar a operação.
 */
int soma(TMatriz A, int nlinA, int ncolA, TMatriz B, int nlinB, int ncolB, TMatriz C, int *nlinC, int *ncolC)
{
    if (nlinA != nlinB || ncolA != ncolB)
    {
        cout << "Não é possível realizar a soma. As matrizes possuem tamanhos diferentes." << endl;
        return 1;
    }
    *nlinC = nlinA;
    *ncolC = ncolA;
    for (int i = 0; i < *nlinC; i++)
    {
        for (int j = 0; j < *ncolC; j++)
        {
            C[i][j] = A[i][j] + B[i][j];
        }
    }
    return 0;
}

/*
 * Função para multiplicar duas matrizes e guardar os valores em uma terceira matriz.
 * Parâmetros:
 *  A, é o endereço da primeira matriz.
 *  nlinA, é o número de linhas da primeira matriz.
 *  ncolA, é o número de colunas da primeira matriz.
 *  B, é o endereço da segunda matriz.
 *  nlinB, é o número de linhas da segunda matriz.
 *  ncolB, é o número de colunas da segunda matriz.
 *  C, é o endereço da terceira matriz.
 *  *nlinC, é o endereço do número de linhas da primeira matriz.
 *  *ncolC, é o endereço do número de colunas da primeira matriz.
 * Retorno:
 *  0, para execução bem suscedida.
 *  1, para quando não é possível executar a operação.
 */
int multiplicacao(TMatriz A, int nlinA, int ncolA, TMatriz B, int nlinB, int ncolB, TMatriz C, int *nlinC, int *ncolC)
{
    if (ncolA != nlinB)
    {
        cout << "Não é possível realizar a multiplicação. O número de colunas de A é diferente do número de linhas de B" << endl;
        return 1;
    }
    *nlinC = nlinA;
    *ncolC = ncolB;
    for (int i = 0; i < *nlinC; i++)
    {
        for (int j = 0; j < *ncolC; j++)
        {
            int soma = 0;
            for (int k = 0; k < ncolA; k++)
            {
                soma = soma + A[i][k] * B[k][j];
            }
            C[i][j] = soma;
        }
    }
    return 0;
}

/*
 * Função para transpor os valores de uma matriz e guardar os valores em uma segunda matriz.
 * Parâmetros:
 *  A, é o endereço da primeira matriz.
 *  nlinA, é o número de linhas da primeira matriz.
 *  ncolA, é o número de colunas da primeira matriz.
 *  B, é o endereço da segunda matriz.
 *  nlinB, é o endereço do número de linhas da segunda matriz.
 *  ncolB, é o endereço do número de colunas da segunda matriz.
 * Retorno:
 * 
 */
void transposta (TMatriz A, int nlinA, int ncolA, TMatriz B, int *nlinB, int *ncolB)
{
    *nlinB = ncolA;
    *ncolB = nlinA;
    for (int i = 0; i < nlinA; i++) 
    {
        for (int j = 0; j < ncolA; j++) 
        {
            B[j][i] = A[i][j];
        }
    }
}

/*
 * Função para calcular a media dos valores de uma matriz.
 * Parâmetros:
 *  A, é o endereço da primeira matriz.
 *  nlinA, é o número de linhas da matriz.
 *  ncolA, é o número de colunas da matriz.
 * Retorno:
 *  media, é a média dos valores.
 */
float media (TMatriz A, int nlinA, int ncolA) 
{
    int soma = 0;
    float media;
    for (int i = 0; i < nlinA; i++) 
    {
        for (int j = 0; j < ncolA; j++) 
        {
            soma = soma + A[i][j];
        }
    }
    media = (float)soma / (nlinA * ncolA);

    return media;
}
