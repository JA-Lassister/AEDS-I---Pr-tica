/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 18 de junho de 2024, 11:24
 */

#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <time.h>
#include "matriz.h"

using namespace std;
/*
 * Função para gerar uma matriz de tamanho determinado pelo usuário
 * preenchida por números aleatórios, que variam entre determinado limite.
 * Parâmetros:
 *  m, é o endereço da matriz.
 *  nlin, é o número de linhas da matriz.
 *  ncol, é o número de colunas da matriz.
 *  lim, é o limite dos valores da matriz (-lim e lim).
 * Retorno:
 *  
 */
void gerarMatriz (TMatriz m, int nlin, int ncol, int lim) 
{
    for (int i = 0; i < nlin; i++) 
    {
        for (int j = 0; j < ncol; j++) 
        {
            m[i][j] = - lim + rand() % (2*lim + 1);
        }
    }
}

/*
 * Função para imprimir os valores de uma matriz na saída.
 * Parâmetros:
 *  m, é o endereço da matriz.
 *  nlin, é o número de linhas da matriz.
 *  ncol, é o número de colunas da matriz.
 * Retorno:
 *   
 */
void imprimir (TMatriz m, int nlin, int ncol) 
{
    for (int i = 0; i < nlin; i++) 
    {
        for (int j = 0; j < ncol; j++) 
        {
            printf("%3d ", m[i][j]);
        }
        cout << endl;
    }
}

/*
 *
 */
int main () {

    srand(time(NULL));

    // Declaração das variáveis.
    TMatriz A, B, C;
    int nlinA, ncolA, nlinB, ncolB, nlinC, ncolC, lim;

    // Definição do tamanho da matriz A.
    cout << "Digite o número de linhas da matriz A: ";
    cin >> nlinA;
    cout << endl;

    cout << "Digite o número de colunas da matriz A: ";
    cin >> ncolA;
    cout << endl;

    // Definição do tamanho da matriz B.
    cout << "Digite o número de linhas da matriz B: ";
    cin >> nlinB;
    cout << endl;

    cout << "Digite o número de colunas da matriz B: ";
    cin >> ncolB;
    cout << endl;

    // Definição do limite dos valores das matrizes.
    cout << "Digite o limite dos valores das matrizes. Os valores irão variar de -lim a lim." << endl;
    cin >> lim;

    // Criação das matrizes.
    gerarMatriz(A, nlinA, ncolA, lim);
    gerarMatriz(B, nlinB, ncolB, lim);

    cout << "Matriz A:" << endl;
    imprimir(A, nlinA, ncolA);
    cout << endl;

    cout << "Matriz B:" << endl;
    imprimir(B, nlinB, ncolB);
    cout << endl;
    
    // Transposta das matrizes.
    cout << "Transposta de A:" << endl;
    transposta(A, nlinA, ncolA, C, &nlinC, &ncolC);
    imprimir(C, nlinC, ncolC);
    cout << endl;
    
    cout << "Transposta de B:" << endl;
    transposta(B, nlinB, ncolB, C, &nlinC, &ncolC);
    imprimir(C, nlinC, ncolC);
    cout << endl;
    
    // Soma das matrizes.
    cout << "Soma A+B:" << endl;
    if (!soma(A, nlinA, ncolA, B, nlinB, ncolB, C, &nlinC, &ncolC))
    {
        imprimir(C, nlinC, ncolC);
    }
    cout << endl;
    
    // Produto das matrizes.
    cout << "Multiplicação A*B:" << endl;
    if (!multiplicacao(A, nlinA, ncolA, B, nlinB, ncolB, C, &nlinC, &ncolC))
    {
        imprimir(C, nlinC, ncolC);
    }
    cout << endl;
    
    // Média das matrizes.
    cout << "Média de A: ";
    cout << media(A, nlinA, ncolA) << endl << endl;
    
    cout << "Média de B: ";
    cout << media(B, nlinB, ncolB) << endl << endl;

    return 0;
}

