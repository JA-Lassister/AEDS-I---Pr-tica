/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 27 de fevereiro de 2024, 17:21
 */

#include <stdio.h>

int main(){

  printf("\n\tHello World\n\n");

  return 0;
}


