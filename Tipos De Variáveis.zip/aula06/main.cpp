/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 25 de março de 2024, 16:07
 */

#include <cstdlib>
#include <stdio.h>

using namespace std;

/*
 * 
 */
int main() {
    
    int variavelint = 50;
    long int variavellongint = 50;
    short int variavelshortint = 50;
    unsigned int variavelunsignedint = 50;
    
    float variavelfloat = 50;
    double variaveldouble = 50;   
    
    printf("\n\tTipos de Variáveis e Alocação de Memória \n\n");
    
    printf("\tVariável Inteira: \n");
    printf("\t\tValor Armazenado: %d\n", variavelint);
    printf("\t\t Endereço na Memória: %p\n", &variavelint);
    printf("\t\tQuantidade em bytes: %li\n", sizeof(int));
    
        int anterior, proximo;
    
        anterior = -1;
        proximo = 0;
        while (proximo > anterior){
            anterior = proximo;
            proximo++;
        }
        printf("\n\tLimite inferior: %d\tLimite Superior: %d\n\n", proximo, anterior);
    
    printf("\tVariável Inteira Long: \n");
    printf("\t\tValor Armazenado: %d\n", variavellongint);
    printf("\t\t Endereço na Memória: %p\n", &variavellongint);
    printf("\t\tQuantidade em bytes: %li\n", sizeof(long int));
    
        long int anteriorlong, proximolong;
    
        anteriorlong = -1;
        proximolong = 0;
        while (proximolong > anteriorlong){
            anteriorlong = proximolong;
            proximolong++;
        }
        printf("\n\tLimite inferior: %d\tLimite Superior: %d\n\n", proximolong, anteriorlong);
    
    printf("\tVariável Inteira Short: \n");
    printf("\t\tValor Armazenado: %d\n", variavelshortint);
    printf("\t\t Endereço na Memória: %p\n", &variavelshortint);
    printf("\t\tQuantidade em bytes: %li\n", sizeof(short int));
    
        short int anteriorshort, proximoshort;
    
        anteriorshort = -1;
        proximoshort = 0;
        while (proximoshort > anteriorshort){
            anteriorshort = proximoshort;
            proximoshort++;
        }
        printf("\n\tLimite inferior: %d\tLimite Superior: %d\n\n", proximoshort, anteriorshort);
    
    printf("\tVariável Inteira Unsigned: \n");
    printf("\t\tValor Armazenado: %d\n", variavelunsignedint);
    printf("\t\t Endereço na Memória: %p\n", &variavelunsignedint);
    printf("\t\tQuantidade em bytes: %li\n", sizeof(unsigned int));
    
        unsigned int anteriorunsigned, proximounsigned;
    
        anteriorunsigned = 1;
        proximounsigned = 2;
        while (proximounsigned > anteriorunsigned){
            anteriorunsigned = proximounsigned;
            proximounsigned++;
        }
        printf("\n\tLimite inferior: %d\tLimite Superior: %d\n\n", proximounsigned, anteriorunsigned);
   
    printf("\tVariável Float: \n");
    printf("\t\tValor Armazenado: %f\n", variavelfloat);
    printf("\t\t Endereço na Memória: %p\n", &variavelfloat);
    printf("\t\tQuantidade em bytes: %li\n", sizeof(float));
    
        float anteriorfloat, proximofloat;
    
        anteriorfloat = -1;
        proximofloat = 0;
        while (proximofloat > anteriorfloat){
            anteriorfloat = proximofloat;
            proximofloat++;
        }
        printf("\n\tLimite inferior: %f\tLimite Superior: %f\n\n", proximofloat, anteriorfloat);
    
    printf("\tVariável Double: \n");
    printf("\t\tValor Armazenado: %f\n", variaveldouble);
    printf("\t\t Endereço na Memória: %p\n", &variaveldouble);
    printf("\t\tQuantidade em bytes: %li\n", sizeof(double));
    
        double anteriordouble, proximodouble;
    
        anteriordouble = -1;
        proximodouble = 0;
        while (proximodouble > anteriordouble){
            anteriordouble = proximodouble;
            proximodouble++;
        }
        printf("\n\tLimite inferior: %f\tLimite Superior: %f\n\n", proximodouble, anteriordouble);
   
    return 0;
}

