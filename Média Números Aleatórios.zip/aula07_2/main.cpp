/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.027
 *
 * Created on 26 de março de 2024, 16:04
 */

#include <time.h>
#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    
    srand (time(NULL));
    
    int i;
    float numero, somatorio;    
    
    i = 0;
    somatorio = 0;
        
    while (i != 1000){           
        numero = rand()%200 + 1;
        i++;
        somatorio = somatorio + numero;
    }
    
    cout << "A média dos números é: " << somatorio / i <<"";
    
    return 0;
}

