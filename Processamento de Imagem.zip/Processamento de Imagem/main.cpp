/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 20 de junho de 2024, 12:30
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <time.h>

using namespace std;

const int TAM = 1024;

typedef int TMatriz[TAM][TAM];

/*
* Função para ler uma imagem PGM, verificar se ela é P2, seu tamanho, seus tons de cinza e armazená-la em uma matriz.
* Parâmetros:
*   m, é o endereço da matriz.
*   nlin, é o endereço do número de linhas da matriz.
*   ncol, é o endereço do número de colunas da matriz.
*   tons, é o endereço do tons de cinza da imagem.
* Retorno:
*   0, para execução bem suscedida.
*   1, para quando o arquivo de imagem não existe.
*   2, para quando a imagem pgm não é P2.
*/
int lerImagem (TMatriz m, int *nlin, int *ncol, int *tons)
{
    string p;
    int n;

    ifstream arquivo("Hyoga.pgm");

    if (!arquivo.is_open())
    {
        return 1;
    }

    arquivo >> p;
    if (p != "P2")
    {
        return 2;
    }

    arquivo >> *ncol;
    arquivo >> *nlin;
    if (*nlin > TAM || *ncol > TAM)
    {
        return 3;
    }
    
    arquivo >> *tons;

    for (int i = 0; i < *nlin; i++)
    {
        for (int j = 0; j < *ncol; j++)
        {
            arquivo >> m[i][j];
        }
    }

    arquivo.close();

    return 0;
    
}

/*
* Função para clarear/escurecer uma imagem PGM e salvá-la em um novo arquivo.
* Parâmetros:
*   m, é o endereço da matriz de imagem.
*   nlin, é o número de linhas da matriz.
*   ncol, é o número de colunas da matriz.
*   n, é a porcentagem passada pelo usuário.
*   tons, é o valor máximo de tons de cinza.
* Retorno:
* 
*/
void luminosidade (TMatriz m, int nlin, int ncol, int n, int tons)
{
    float p = 1;

    p = p + (n / 100.0);

    ofstream arquivo("luminosidade.pgm");

    arquivo << "P2" << endl;
    arquivo << ncol << " " << nlin << endl;
    arquivo << tons << endl;

    for (int i = 0; i < nlin; i++)
    {
        for (int j = 0; j < ncol; j++)
        {
            if (m[i][j] * p > tons)
            {
                arquivo << tons  << " ";
            }
            else
            {
                int w = m[i][j] * p;
                arquivo << w << " ";
            }
        }
        arquivo << endl;
    }

    arquivo.close();
}

/*
* Função para encontrar a imagem negativa de uma imagem PGM e salvá-la em um novo arquivo.
* Parâmetros:
*   m, é o endereço da matriz imagem.
*   nlin, é o número de linhas da matriz.
*   ncol, é o número de colunas da matriz.
*   tons, é o valor máximo de tons de cinza.
* Retorno:
*
*/
void negativo (TMatriz m, int nlin, int ncol, int tons)
{
    ofstream arquivo("negativo.pgm");

    arquivo << "P2" << endl;
    arquivo << ncol << " " << nlin << endl;
    arquivo << tons << endl;

    for (int i = 0; i < nlin; i++)
    {
        for (int j = 0; j < ncol; j++)
        {
            arquivo << tons - m[i][j] << " ";
        }
        arquivo << endl;
    }

    arquivo.close();
}

/*
* Função para binarizar uma imagem PGM a partir de um fator passado pelo usuário e salvá-la em um novo arquivo.
* Parâmetros:
*   m, é o endereço da matriz imagem.
*   nlin, é o número de linhas da matriz.
*   ncol, é o número de colunas da matriz.
*   tons, é o valor máximo de tons de cinza.
*   n, é o fator passado pelo usuário.
* Retorno:
* 
*/
void binarizar (TMatriz m, int nlin, int ncol, int tons, int n)
{
    ofstream arquivo("binarizado.pgm");

    arquivo << "P2" << endl;
    arquivo << ncol << " " << nlin << endl;
    arquivo << tons << endl;
    
    if (n == 0) 
    {
        for (int i = 0; i < nlin; i++)
        {
            for (int j = 0; j < ncol; j++)
            {
                if (m[i][j] = n)
                {
                    arquivo << 0 << " ";
                } 
                else 
                {
                    arquivo << tons << " ";
                }
            }
            arquivo << endl;
        }
    }
    else
    {
        for (int i = 0; i < nlin; i++)
        {
            for (int j = 0; j < ncol; j++)
            {
                if (m[i][j] < n)
                {
                    arquivo << 0 << " ";
                } 
                else 
                {
                    arquivo << tons << " ";
                }
            }
            arquivo << endl;
        }
    }
    
    arquivo.close();
}

/*
* Função para iconizar uma imagem PGM para 64x64 e salvá-la em um novo arquivo.
* Parâmetros:
*   m, é o endereço da matriz imagem.
*   nlin, é o número de linhas da matriz.
*   ncol, é o número de colunas da matriz.
*   tons, é o valor máximo de tons de cinza.
* Retorno:
*
*/
void iconizar (TMatriz m, int nlin, int ncol, int tons)
{
    ofstream arquivo("iconizado.pgm");

    arquivo << "P2" << endl;
    arquivo << 64 << " " << 64 << endl;
    arquivo << tons << endl;

    nlin = nlin / 64;
    ncol = ncol / 64;

    for (int i = 0; i < 64; i++)
    {
        for (int j = 0; j < 64; j++)
        {
            int soma = 0;
            for (int k = i * nlin; k < nlin * (i + 1); k++)
            {
                for (int l = j * ncol; l < ncol * (j + 1); l++)
                {
                    soma = soma + m[k][l];
                }
            }
            arquivo << soma / (nlin * ncol) << " ";
            if (j == 63)
            {
                arquivo << endl;
            }
        }
    }

    arquivo.close();
}

/*
* Função para gerar ruído em uma imagem PGM e salvá-la em um novo arquivo.
* Parâmetros:
*   m, é o endereço da matriz imagem.
*   nlin, é o número de linhas da matriz.
*   ncol, é o número de colunas da matriz.
*   tons, é o valor máximo de tons de cinza.
* Retorno:
*
*/
void ruido (TMatriz m, int nlin, int ncol, int tons)
{
    srand(time(NULL));
    
    ofstream arquivo("ruido.pgm");

    arquivo << "P2" << endl;
    arquivo << ncol << " " << nlin << endl;
    arquivo << tons << endl;

    for (int i = 0; i < nlin; i++)
    {
        for (int j = 0; j < ncol; j++)
        {
            int n = rand() % (10 + 1);
            if (n == 0)
            {
                arquivo << 0 << " ";
            }
            else
                if (n == 10)
                {
                    arquivo << tons << " ";
                }
                else
                    arquivo << m[i][j] << " ";
        }
        arquivo << endl;
    }
}


void suavizar (TMatriz m, int nlin, int ncol, int tons)
{
    ofstream arquivo("suavizado.pgm");

    arquivo << "P2" << endl;
    arquivo << ncol - 2 << " " << nlin - 2 << endl;
    arquivo << tons << endl;

    for (int i = 1; i < nlin - 1; i++)
    {
        for (int j = 1; j < ncol - 1; j++)
        {
            int v[9];
            for (int k = -1; k <= 1; k++)
            {
                for (int l = -1; l <= 1; l++)
                {
                    v[3 * (k + 1) + l + 1] = m[i+k][j+l];
                }
            }
            // Ordenação do vetor
            int aux, m;
            for (int n = 1; n < 9; n++)
            {
                aux = v[n];
                m = n - 1;
                while (m >= 0 && v[m] > aux)
                {
                    v[m + 1] = v[m];
                    m = m - 1;
                }
                v[m + 1] = aux;
            }
            arquivo << v[4] << " ";
            if (j == ncol - 2)
            {
                arquivo << endl;
            }
        }
    }

    arquivo.close();
}

int main ()
{
    // Declaração das varáveis
    TMatriz m;
    int nlin, ncol, tons, e, menu, opcao, n;

    e = lerImagem(m, &nlin, &ncol, &tons);

    // Possíveis erros na leitura da imagem
    if (e == 1)
    {
        cout << "Erro. Arquivo inexistente." << endl;
    }
    if (e == 2)
    {
        cout << "Erro. A imagem PGM não é do tipo P2." << endl;
    }
    if (e == 3)
    {
        cout << "Erro. A resolução da imagem é muito grande." << endl;
    }

    // Menu de opções
    do
    {
        cout << "Digite o número referente a operação que deseja realizar" << endl;
        cout << " 1 - Escurecer ou clarear a imagem." << endl;
        cout << " 2 - Encontrar a imagem negativa." << endl;
        cout << " 3 - Binarizar a imagem." << endl;
        cout << " 4 - Iconizar a imagem" << endl;
        cout << " 5 - Criar ruídos na imagem." << endl;
        cout << " 6 - Suavizar a imagem" << endl;
        cout << "             0 - Encerrar programa." << endl;
        cin >> menu;

        switch (menu)
        {
            // Encerrar programa
            case 0:
                break;
            // Clarear ou escurecer a imagem
            case 1:
                cout << "Deseja escurecer ou clarear a imagem?" << endl;
                cout << "Digite 0 para ESCURECER ou 1 para CLAREAR: ";
                cin >> opcao;
                cout << endl;

                switch (opcao)
                {
                    case 0:
                        cout << "Digite a porcentagem que deseja escurecer a imagem: ";
                        cin >> n;
                        n = -n;
                        break;
                    case 1:
                        cout << "Digite a porcentagem que deseja clarear a imagem: ";
                        cin >> n;
                        break;
                    default:
                        cout << "Opção inválida. Digite novamente." << endl;
                        menu = 1;
                        break;
                }

                luminosidade(m, nlin, ncol, n, tons);

                cout << "\nImagem 'luminosidade.pgm' gerada." << endl << endl;
                break;
            // Gerar o negaativo da imagem
            case 2:
                negativo(m, nlin, ncol, tons);

                cout << "\nImagem 'negativo.pgm' gerada." << endl << endl;
                break;
            // Binarizar a imagem
            case 3:
                cout << "Digite o fator para binarização: ";
                cin >> n;
                cout << endl;
                
                if (n < 0 || n > tons)
                {
                    cout << "O valor deve estar entre 0 e " << tons << ". Digite novamente." << endl;
                    menu = 3;
                }
                else
                binarizar(m, nlin, ncol, tons, n);
                cout << "\nImagem 'binarizado.pgm' gerada." << endl << endl;
                break;
            // Iconizar a imagem
            case 4:
                iconizar(m, nlin, ncol, tons);
                cout << "\nImagem 'iconizado.pgm' gerada." << endl << endl;
                break;
            // Gerar ruído na imagem
            case 5:
                ruido(m, nlin, ncol, tons);
                cout << "\nImagem 'ruido.pgm' gerada." << endl << endl;
                break;
            // Suavizar a imagem.
            case 6:
                suavizar(m, nlin, ncol, tons);
                cout << "\nImagem 'suavizado.pgm' gerada." << endl << endl;
                break;
            default:
                cout << "Opção inválida. Digite novamente." << endl << endl;
                break;
        }
    } while (menu != 0);

    return 0;    
}



