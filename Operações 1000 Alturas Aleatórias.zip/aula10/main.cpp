/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo 2024.1.08.027
 *
 * Created on 9 de abril de 2024, 16:22
 */

#include <time.h>
#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

int main() {
    
    srand (time(NULL));
    
    const int TAM = 1000;
    
    int i, q, acima;
    float p, s, altura[TAM], menor, maior, somatorio, media, porcentagem, dp;    
    
    somatorio = 0;
    p = 0;
    s = 0;
    menor = 2,4;
    maior = 0;
    acima = 0;
    
    for (i = 0; i < TAM; i++){
        altura[i] = rand()%81 + 150;
        altura[i] = altura[i] / 100;
        somatorio = somatorio + altura[i];
        if (altura[i] > 2.0)
            p++;
        if (altura[i] < menor)
            menor = altura[i];
        if (altura[i] > maior)
            maior = altura[i];
    }
    
    media = somatorio / TAM;
    
    for (q = 0; q < TAM; q++){
        s = s + (altura[q] - media) * (altura[q] - media) / TAM;
        if (altura[q] < media)
            acima++;         
    }
    
    porcentagem = p * 100 / TAM;
    dp = sqrt(s);
    
    cout << "Gerador de 1000 alturas aleatórias.\n" << endl;
    cout << fixed << setprecision(2);
    cout << "A média das alturas é: " << media << "m" << endl;
    cout << "\nA menor altura é: " << menor << "m""\t\tA maior altura é: " << maior << "m" << endl;
    cout << "\nA porcentagem de pessoas maiores de 2,0 metros é: " << porcentagem << "%" << endl;
    cout << "\nA quantidade de pessoas acima da média é: " << acima << endl;
    cout << "\nO desvio padrão foi de: " << dp << endl;
    
    return 0;
}


