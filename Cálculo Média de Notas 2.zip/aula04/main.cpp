
/* 
 * File:   main.cpp
 * Author: João Antonio Lassister Melo
 *
 * Created on 27 de fevereiro de 2024, 17:21
 */

/**/

#include <stdio.h>

int main(){
    
    float nota1, nota2, nota3, media;

    printf("Digite a nota da primeira prova: ");
    scanf(" %f", &nota1);
    while(nota1 < 0 || nota1 > 10){
        printf("Valor incorreto. Digite novamente:");
        scanf(" %f", &nota1);
    }
    
    printf("\nDigite a nota da segunda prova: ");
    scanf(" %f", &nota2);
    while(nota2 < 0 || nota2 > 10){
        printf("Valor incorreto. Digite novamente:");
        scanf(" %f", &nota2);
    }
    
    printf("\nDigite a nota do trabalho: ");
    scanf(" %f", &nota3);
    while(nota3 < 0 || nota3 > 10){
        printf("Valor incorreto. Digite novamente:");
        scanf(" %f", &nota3);
    }
    
    media = (nota1*0.3+nota2*0.3+nota3*0.4);
    
    printf("\n\tA média de AEDs I Prática é %.2f \n", media);
    
    if (media < 6.0){
        printf("\tVocê está reprovado.");
    } else printf("\n\tVocê está aprovado.");
     
  return 0;
}


